# Direção de arte B — GameDev / The Worldbuilder

## North star
**Interactive Game Atlas + Cinematic Fantasy.** O portfólio se comporta como um mundo explorável, mas também oferece catálogo direto. Não é um jogo obrigatório para chegar ao trabalho.

## Moodboard verbal
Ruínas abstratas, mapa de mundos, arquitetura impossível, neblina volumétrica simulada, interfaces diegéticas, iluminação âmbar e violeta, materiais com desgaste, sensação de mistério e descoberta. Não imitar IPs de jogos existentes.

## Paleta exploratória
Background #090B14; surface #15192A; foreground #F6F1E9; muted #B5B4C7; amber #E8B56B; violet #8C7AE6; fog #39405B. Testar contrastes de texto sobre imagem.

## Tipografia candidata
Display: serif editorial expressiva (ex.: Cormorant Garamond, com teste de legibilidade) ou display custom original; UI: Manrope/Inter; metadados: mono discreta. Não depender de fonte “medieval” caricata.

## Hero — composição
- Cena ilustrada ou 3D estilizada com uma estrutura central e pontos de interesse.
- Título claro “Games & Experiments” ou nome real da seção.
- CTA primário “Browse projects” e secundário “Explore world”.
- Informação de status: “3 playable prototypes”, apenas se houver três protótipos jogáveis reais.
- Controles explícitos: reduzir movimento, sair do modo imersivo, áudio off por padrão.

## Modelo de atlas
Cada ponto representa um projeto com rótulo e estado. Hover/focus abre painel HTML com teaser e ação. Click leva a URL de case real; histórico e navegação funcionam normalmente. Uma lista HTML equivalente permanece acessível.

## Motion assinatura
Movimento de câmera suave, paralaxe, partículas moderadas, luz reativa, transições de profundidade. Não usar movimento contínuo agressivo, shake ou flash. Motion reduzido troca cena por poster estático.

## Case de jogo
Gameplay no topo; loop principal em 3 frases; plataforma, engine, papel, estado do projeto; mecânicas e iterações; vídeo com legendas; link de build se seguro; aprendizados. Concept art explicitamente rotulada.

## Estratégia de assets
Primeiro 2D/2.5D com parallax CSS; testar WebGL só após validar o atlas e os cases. Usar glTF/GLB otimizado, texturas comprimidas, LOD, fallback, carregamento sob demanda.

## Anti-padrões
HUD intrusiva, minigame obrigatório, preloader teatral, áudio autoplay, navegação por câmera sem alternativa, visuais que se apropriam de arte de jogos comerciais.

## Experimentos de Claude Design
B1 — mapa astral de projetos; B2 — museu de artefatos; B3 — portal arquitetônico com salas. Escolher por viabilidade de assets e clareza.