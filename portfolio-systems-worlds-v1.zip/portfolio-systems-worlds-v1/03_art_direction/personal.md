# Direção de arte C — Personal / The Observer

## North star
**Contemporary Japanese Editorial + Digital Garden.** Uma publicação autoral viva: pensamento, notas, estudos e experiências. Influência japonesa como disciplina de composição, ritmo e materialidade, não como decoração cultural.

## Moodboard verbal
Livros de arte contemporâneos; capas de revistas independentes; assimetria; espaço negativo; textura de papel; tinta e impressão; fotografia cotidiana; linhas editoriais; pequenos detalhes de margem.

## Paleta exploratória
Paper #F1EDE4; ink #1C1B19; muted #676258; vermilion #B54837; sage #737A64; border #D1C9BB. Verificar contraste, especialmente em muted e sage.

## Tipografia candidata
Display: serif editorial (Noto Serif, Fraunces ou outra após testes); corpo: sans humanista; metadados: mono suave. Usar fontes japonesas apenas para conteúdo realmente em japonês e com cuidado de peso/download.

## Hero — composição
Uma frase curta autoral, um retrato/objeto/foto real se desejado, uma anotação lateral e navegação para “Notes”, “Now”, “Experiments”. Evitar a estética de currículo duplicado; o objetivo é ampliar a pessoa por trás do trabalho.

## Movimento assinatura
Revelação como impressão, linhas desenhadas, deslocamento sutil de folhas, pequenos detalhes responsivos. Easing mais lento e orgânico, sem forçar rolagem. Reduced motion conserva a composição.

## Digital garden
Conteúdos por tipo: note, essay, experiment, collection. Mostrar status de maturidade (seedling/growing/evergreen) **somente se a metáfora fizer sentido** e com datas reais. Navegação por tema e backlinks opcionais; começar simples.

## Componentes especiais
Notas de margem, legendas editoriais, citações próprias, coleções de referências, timeline, bloco “currently exploring”, cartões de experimento. Imagens devem ter legenda, origem e alt.

## Respeito cultural
Não usar kanji aleatórios, selo vermelho pseudo-japonês ou símbolos tradicionais fora de contexto. Estudar trabalhos de designers japoneses contemporâneos e atribuir referências; testar se a composição funciona mesmo sem qualquer símbolo cultural.

## Experimentos de Claude Design
C1 — caderno editorial; C2 — arquivo fotográfico; C3 — exposição tipográfica. Escolher a direção que melhor represente materiais reais disponíveis.