# Motion language — especificação de comportamento

## Princípio
Movimento serve a orientação, hierarquia, feedback, continuidade ou atmosfera. Todo efeito tem justificativa, gatilho, duração, saída, fallback e teste de acessibilidade.

## Escala temporal inicial
| Classe | Duração indicativa | Uso |
| --- | --- | --- |
| micro | 100–180 ms | hover, press, toggle |
| short | 180–300 ms | painel, botão, foco |
| medium | 300–500 ms | reveal, transição de bloco |
| narrative | 500–900 ms | sequência cinematográfica optativa |
| ambient | contínuo e muito sutil | atmosfera; desligável |

Evitar delay de entrada em controles essenciais. Não usar todas as classes em toda página.

## Easing proposto
Software: cubic-bezier(0.22,1,0.36,1), firme e preciso.  
GameDev: cubic-bezier(0.16,1,0.3,1), desaceleração espacial.  
Personal: cubic-bezier(0.25,0.1,0.25,1), suave e orgânico.  
Validar em protótipo; números são hipóteses.

## Sequência padrão de hero
**Software:** linhas da headline → grid se alinha → diagrama surge.  
**Games:** ambiente aparece → foco ilumina artefato → CTA e rótulos entram.  
**Personal:** composição editorial já legível → linha de margem é desenhada → imagem revela textura.

## Orquestração
Preferir CSS para estados simples. Usar biblioteca de motion apenas para transições coordenadas. Se GSAP for escolhido para timeline complexa, evitar outra biblioteca fazendo a mesma função. WebGL não deve controlar o DOM crítico.

## Performance
Animar transform e opacity; evitar filtros grandes, blur em full screen e layout thrash. Medir FPS e long tasks em dispositivos medianos. Pausar animações fora da viewport. Descarregar listeners e RAF. Respeitar visibilidade da página.

## Preferências do usuário
`prefers-reduced-motion: reduce` desativa deslocamento espacial e loops. Fornecer toggle “Motion: on/off” no modo imersivo, se houver. Persistência opcional com respeito à privacidade.

## Storyboard e estados
Para cada animação registrar: id, elemento, estado inicial/final, trigger, duration, easing, interruption, reduced-motion, teclado, fallback, orçamento de performance. Ver 09_visuals/motion-storyboard.svg.

## QA de movimento
Sem flashes rápidos; sem perda de foco; sem elementos clicáveis invisíveis; sem salto de layout; sem motion obrigatória; sem CTA bloqueado; sem falha quando a navegação ocorre no meio da transição.