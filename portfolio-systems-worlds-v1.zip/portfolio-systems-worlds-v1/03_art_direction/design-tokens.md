# Design tokens — contrato exploratório

## Organização
**Core:** spacing, radii, type scale, z-index, duração, breakpoints.  
**Semantic:** background, surface, foreground, muted, border, accent, focus.  
**Theme:** work, games, personal.  
Tokens são candidatos e só se tornam definitivos após teste visual e contraste.

## Paletas
| Token | Software | GameDev | Pessoal |
| --- | --- | --- | --- |
| bg | #0B0D10 | #090B14 | #F1EDE4 |
| surface | #171A20 | #15192A | #E8E1D5 |
| fg | #F3F2EE | #F6F1E9 | #1C1B19 |
| muted | #A6ACB5 | #B5B4C7 | #676258 |
| accent | #C8F26A | #E8B56B | #B54837 |
| border | #2B3038 | #39405B | #D1C9BB |

## Escala de espaço (4px base)
1=4; 2=8; 3=12; 4=16; 6=24; 8=32; 12=48; 16=64; 24=96; 32=128. Permitir valores fluidos em seções hero.

## Tipo
Body: clamp(1rem, 0.95rem + 0.2vw, 1.125rem).  
Display: clamp(3rem, 7.5vw, 8.5rem).  
Line-height display: 0.9–1.05 conforme fonte; corpo 1.5–1.7.  
Largura ideal de texto longo: 60–75ch.

## Grid
Software: 12 colunas desktop, 6 tablet, 4 mobile.  
Games: layout em camadas com safe area para HUD.  
Pessoal: grid editorial de 12 colunas, quebrado intencionalmente por blocos de margem.

## Exemplo CSS
```css
:root {
  --space-1: .25rem; --space-2: .5rem; --space-4: 1rem;
  --space-8: 2rem; --space-12: 3rem; --space-24: 6rem;
  --duration-micro: 140ms; --duration-short: 240ms; --duration-medium: 420ms;
  --ease-precision: cubic-bezier(.22,1,.36,1);
  --ease-spatial: cubic-bezier(.16,1,.3,1);
  --ease-organic: cubic-bezier(.25,.1,.25,1);
}
[data-world="work"] { --bg:#0B0D10; --fg:#F3F2EE; --accent:#C8F26A; --surface:#171A20; }
[data-world="games"] { --bg:#090B14; --fg:#F6F1E9; --accent:#E8B56B; --surface:#15192A; }
[data-world="personal"] { --bg:#F1EDE4; --fg:#1C1B19; --accent:#B54837; --surface:#E8E1D5; }
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration:.01ms !important; transition-duration:.01ms !important; scroll-behavior:auto !important; }
}
```

## Componentes base
GlobalNav, WorldSwitcher, Hero, ProjectCard, CaseSection, MediaFigure, MetricWithSource, MotionToggle, Breadcrumbs, ContactCTA, SkipLink, AccessibleDialog. Variantes visuais por tema; sem duplicar lógica.

## Verificações
Contrast ratio real por par; foco sobre backgrounds; densidade mobile; line breaks em pt-BR/en-US; fontes licenciadas; clipping e legibilidade com zoom.