# Sistema de identidade compartilhada

## Conceito-mãe
**Systems & Worlds** é o título de trabalho. A assinatura deve ser reconhecível mesmo quando a estética muda radicalmente. Evitar impor uma única paleta ou um único grid a tudo.

## Constantes
1. **Marca metamórfica:** símbolo simples que funciona em SVG, linha, relevo e volume.
2. **Clareza editorial:** cada página responde “o quê”, “por quê”, “como”, “resultado”.
3. **Precisão de acabamento:** spacing, transições, feedback e tipografia intencionais.
4. **Trilha global:** Software / Games / Personal, sempre localizável.
5. **Voz:** curiosidade, competência e humanidade.
6. **Padrões de acessibilidade:** mesmo nível de qualidade nos três mundos.

## Variáveis por mundo
| Eixo | Software | Games | Personal |
| --- | --- | --- | --- |
| Composição | grid modular | profundidade e cenário | página editorial assimétrica |
| Material | metal fosco / linhas | pedra / névoa / luz | papel / tinta / fotografia |
| Movimento | mecânico e preciso | cinematográfico e espacial | orgânico e contemplativo |
| Densidade | média | variável | baixa a média |
| Cor | carvão + lime ácido | noite + âmbar + violeta | marfim + tinta + vermelhão |
| Interação | revelar sistema | explorar mundo | descobrir notas |

## Logo / marca
Criar no mínimo 12 estudos preto-e-branco. Testar legibilidade em 16px, 32px e 128px; animação de morph; impressão monocromática; favicon. Evitar símbolos óbvios como </>, joystick ou flor de cerejeira.

## Fotografia e imagem
Projetos reais sempre têm prioridade. Arte abstrata é suporte, não substituto de screenshot, gameplay ou prova. A direção pessoal pode usar fotos próprias, digitalizações e texturas com direitos claros.

## Consistência invisível
Mesmo vocabulário de estados (hover, focus, active, loading), convenções de link, escala de spacing e modelo de conteúdo. A aparência muda; a previsibilidade de uso permanece.

## Checklist de aprovação
Conceitos distinguíveis sem títulos? O mesmo autor é percebido? O símbolo funciona sem motion? A home profissional permanece legível em 320px? Os assets têm licenças?