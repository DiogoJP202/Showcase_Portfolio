# Direção de arte A — Software / The Architect

## North star
**Kinetic Editorial + Precision Engineering.** Um produto premium com presença editorial, não um dashboard genérico. O WOW vem de tipografia, composição, ritmo e detalhes técnicos que se organizam em resposta à interação.

## Moodboard verbal
Modernismo suíço contemporâneo; pôster tipográfico; fotografia arquitetônica; diagramas de sistemas; materiais foscos; linhas técnicas; contraste intenso; espaços negativos controlados.

## Paleta exploratória
Background #0B0D10; surface #171A20; foreground #F3F2EE; muted #A6ACB5; accent #C8F26A; grid #2B3038. Verificar contraste antes de aprovar.

## Tipografia candidata
Display: Space Grotesk ou Instrument Sans (validar licenças e versões). Corpo: Inter / Instrument Sans. Metadados: IBM Plex Mono. Tipografia é estrutura, não ornamento: escala ampla, tracking intencional, colunas fortes.

## Hero — composição
- Headline dominante em 2–3 linhas com nome e função real.
- Subheadline de 1–2 linhas, sem buzzwords.
- CTA principal “Selected work”; secundário “About”.
- Diagrama de nós e trilhas na lateral ou ao fundo; decorativo.
- Status/índice discreto com número de cases e localização **somente se real**.
- Espaço suficiente para ler imediatamente.

## Sequência de motion
0–120 ms: fundo e layout disponíveis; 120–450 ms: headline revela por linhas; 250–650 ms: diagrama se organiza; 500–750 ms: microdetalhes estabilizam. CTA não espera a sequência. Durações são ponto de partida, não especificação final.

## Cases
Cards editoriais de proporções variadas, cada um com problema e resultado; alternar composição e ritmo sem perder previsibilidade. Dentro do case, usar diagramas reais, blocos de decisão e imagens do produto. Evitar seções de skills como nuvem infinita de logos.

## Interações assinatura
Hover que desenha linhas de arquitetura; títulos que respondem ao scroll sem bloquear; reveal de componentes; detalhe de cursor sutil **somente se não interferir**.

## Mobile
Hero estático e forte; tipografia fluida; diagrama simplificado; CTA acima da dobra quando possível; sem interações exclusivas de hover.

## Anti-padrões
Terminal fake, partículas aleatórias, code rain, gradiente neon indiscriminado, excesso de glassmorphism, textos microscópicos, métricas inventadas.

## Experimentos de Claude Design
A1 — manifesto tipográfico quase monocromático; A2 — diagrama estrutural como protagonista; A3 — revista tecnológica com blocos editoriais. Gerar três style frames e comparar clareza/impacto.