# Referências, fontes e status de verificação

## Fontes do autor — URLs fornecidas, auditoria pendente
- LinkedIn: https://www.linkedin.com/in/diogo-antonny/
- Portfólio atual: https://diogojp202.github.io/Portfolio/
- GitHub: https://github.com/DiogoJP202/

## Nove referências prioritárias — seleção do autor
- João Victor: https://www.joaovictord.dev/
- Zeno Rocha: https://zenorocha.com/
- Bruno Simon: https://bruno-simon.com/
- Hyoil: https://www.hyoil.blog/
- Guilherme Padovani: https://www.guilhermepadovani.com/
- Lucas Pope: https://dukope.com/
- Coldwet Games: https://coldwetgames.com/
- Cristiano Dalbem: https://www.cristianodalbem.com/
- Caio Campos: https://caiocampos.com.br/

As URLs foram fornecidas pelo usuário e **não foram auditadas novamente nesta compilação**. As características abaixo são hipóteses de inspiração discutidas na conversa; confirmar com a pesquisa e com inspeção real.

## Referências mencionadas na conversa
- Yuta Asakura — perfil LinkedIn fornecido: https://www.linkedin.com/in/yuta-asakura/
- Yusuke Sano — perfil LinkedIn fornecido: https://www.linkedin.com/in/yusuke-sano-8722631a2/
- Portfólio mencionado em conversa anterior: https://asakurayuta.dev/ — correspondência e disponibilidade a verificar.
- Portfólio mencionado em conversa anterior: https://yusuke.sn/ — correspondência e disponibilidade a verificar.

**Status:** estes links são pontos de partida, não fichas de análise concluídas. Não atribuir detalhes de UI, tecnologias, autoria ou prêmios sem conferência.

## Leituras técnicas oficiais para consultar na implementação
- WCAG 2.2: https://www.w3.org/TR/WCAG22/
- Quick reference: https://www.w3.org/WAI/WCAG22/quickref/
- Web Vitals: https://web.dev/articles/vitals
- MDN CSS prefers-reduced-motion: https://developer.mozilla.org/en-US/docs/Web/CSS/@media/prefers-reduced-motion
- MDN Web Animations API: https://developer.mozilla.org/en-US/docs/Web/API/Web_Animations_API
- Next.js docs: https://nextjs.org/docs
- Three.js docs: https://threejs.org/docs/
- React Three Fiber: https://r3f.docs.pmnd.rs/

Os links acima são materiais de referência conhecidos; não representam uma auditoria online de suas versões em 13/11/2026.

## Bibliografia de design — a compilar
Registrar trabalhos concretos e atribuições da pesquisa profunda, incluindo criadores brasileiros, internacionais, japoneses e de outras regiões asiáticas. Não incluir ranking fabricado.

## Direitos
Assets e screenshots de referência não foram incluídos no ZIP. Os vetores e HTML exploratórios da pasta 09_visuals são composições originais deste briefing.