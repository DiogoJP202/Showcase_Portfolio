# Rubrica de revisão de direção de arte

## Escala
1 = insuficiente; 2 = fraco; 3 = adequado; 4 = muito bom; 5 = excepcional. Pontuar com justificativa e evidência, não só preferência.

| Critério | Peso | Pergunta |
| --- | --- | --- |
| Clareza em 5 segundos | 20% | sei quem é e onde clicar? |
| Originalidade | 20% | parece autoral ou template? |
| Coerência de marca | 15% | três mundos pertencem ao mesmo autor? |
| Qualidade visual | 15% | tipografia, grid, ritmo, acabamento? |
| Conteúdo e prova | 10% | cases são protagonistas? |
| Mobile e a11y | 10% | funciona sem mouse e motion? |
| Viabilidade e performance | 10% | pode ser construído e mantido? |

## Planilha manual de decisão
Para cada conceito registrar notas, evidências, pontos fortes, riscos, perguntas e decisão. Média ponderada = soma(nota × peso). Não escolher por nota se houver falha impeditiva de acessibilidade ou conteúdo.

## Sinais de design genérico
Hero com gradient blob e “Hi, I'm”; cards idênticos; skills em nuvem; tipografia padrão sem hierarquia; efeitos de hover sem propósito; seção de testemunhos inventados; ausência de material real.

## Sinais de conceito forte
Metáfora visual consistente; composição memorável; marca reconhecível; conteúdo técnico legível; movimento com semântica; mobile redesenhado (não só empilhado); estilo não depende de asset proprietário.

## Review ritual
Rodada 1: impacto sem explicação. Rodada 2: leitura e navegação. Rodada 3: factibilidade e acessibilidade. Rodada 4: comparação com referências e detecção de cópia. Registrar feedback divergente e trade-offs.

## Decisão
Aprovar, iterar ou rejeitar. Para aprovar: clareza ≥4, originalidade ≥4, qualidade ≥4, a11y ≥4 e nenhum bloqueio grave. Esses limiares são internos e ajustáveis.