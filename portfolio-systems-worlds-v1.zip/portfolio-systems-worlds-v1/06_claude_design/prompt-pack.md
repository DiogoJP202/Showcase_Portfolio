# Claude Design — prompt pack de direção de arte

## Modo de uso
Enviar **um prompt por etapa**, com referências e conteúdo reais. Primeiro gerar direção de arte, depois style frames, depois motion, depois componentes. Não pedir site inteiro no primeiro prompt. Exigir alternativas realmente diferentes, rationale e mobile.

## Prompt 01 — Creative direction master (EN)
```text
Act as a senior creative director and digital experience designer for an award-caliber independent portfolio ecosystem.

Project working title: "Systems & Worlds".
Core idea: one person, three distinct digital worlds:
1) Software / The Architect — kinetic editorial + precision engineering.
2) GameDev / The Worldbuilder — interactive game atlas + cinematic atmosphere.
3) Personal / The Observer — contemporary Japanese editorial + digital garden.

Goal: create memorable, original, visually ambitious experiences that make visitors say WOW, without sacrificing clarity, accessibility, mobile usability or technical performance.

Do NOT create a generic developer portfolio. Avoid fake terminals, code rain, random gradients, repeated cards, cliché game HUDs and superficial Japanese symbolism. Do NOT copy existing sites or fabricate projects.

Brand signature: a simple geometric symbol that changes material across worlds (technical wireframe, luminous artifact, ink on paper). Shared navigation and interaction quality; radically different visual compositions.

For each world deliver:
- concept statement and emotional target;
- 3 visual territory alternatives;
- typography pairing (with licensing caveat);
- palette and contrast considerations;
- grid, composition and visual material;
- hero layout with clear content hierarchy and CTA;
- project card and case page art direction;
- mobile adaptation;
- signature motion ideas and reduced-motion fallback;
- originality risks and implementation risks.

Start with art direction and static style frames. DO NOT implement the entire site yet. Clearly label hypotheses and placeholders.
```

## Prompt 02 — Software hero
```text
Design three radically different high-fidelity static hero concepts for "Software / The Architect". Aim for premium kinetic editorial design, Swiss-inspired grid discipline, strong typographic hierarchy and subtle system diagrams. Show real content placeholders as clearly labeled placeholders. Primary CTA "Selected work" must be immediately visible. Explore: (A) typographic manifesto, (B) structural diagram, (C) editorial technology journal. Provide desktop 1440 and mobile 390 compositions, spacing logic, type scale and rationale. Avoid dashboard clichés and fake code interfaces.
```

## Prompt 03 — GameDev hero and atlas
```text
Explore three original art directions for a GameDev portfolio: (A) constellation of worlds, (B) museum of artifacts, (C) architectural portal. Create atmospheric, cinematic style frames without borrowing recognizable game IP. Include two equally valid entry paths: "Browse projects" (primary, accessible) and "Explore world" (optional immersive mode). Show how project information is exposed in semantic HTML and how the experience works with no WebGL, reduced motion, touch and keyboard.
```

## Prompt 04 — Personal digital garden
```text
Create an original contemporary editorial direction for a personal digital garden, informed by Japanese graphic design principles: asymmetry, rhythm, negative space, print texture and careful typography. Avoid random kanji, cherry blossoms or cultural decoration. Explore three variants: field notebook, photographic archive, typographic exhibition. Include notes, now page, timeline, experiments and a personal statement. Show desktop/mobile and explain how the identity remains connected to the other two worlds.
```

## Prompt 05 — Motion storyboard
```text
For the approved static direction, produce a motion storyboard (not code yet). For each key interaction list trigger, initial/final state, duration, easing, visual purpose, interruption behavior, reduced-motion alternative, mobile behavior and performance risk. Include hero reveal, project card hover/focus, page transition, world switch, case reveal and GameDev atlas interaction. Ensure CTA and content never wait for animation.
```

## Prompt 06 — Shared brand mark
```text
Create 12 black-and-white original geometric mark studies for one creator with three worlds. The symbol must survive 16px favicon, 32px navigation, 128px poster, monochrome print and material transformations: precise wireframe, luminous 3D artifact, ink on paper. Avoid literal code brackets, gamepads and Japanese motifs. Evaluate memorability, simplicity, motion potential and accessibility.
```

## Prompt 07 — Design system handoff
```text
Translate the approved visual concept into a production design specification. Include semantic design tokens, typography scale, responsive grid, spacing, component anatomy, all interactive states, motion timings, accessibility, asset export requirements and page templates. Clearly separate global tokens from world-specific themes. Provide explicit implementation notes and unresolved decisions; do not invent content.
```

## Prompt 08 — Critical review
```text
Act as a skeptical design director, accessibility specialist and performance engineer. Critique the proposal against originality, clarity in five seconds, credibility, content depth, mobile usability, keyboard access, reduced motion, bundle/performance risk and maintainability. Identify the five highest-risk choices and propose concrete alternatives. Do not flatter the design.
```

## Iteration protocol
1. Gerar 3 variantes por mundo, não só variações de cor.
2. Selecionar 1–2 por rubrica.
3. Produzir hero, case, índice e mobile.
4. Validar com pessoas.
5. Só então gerar motion storyboard e POC.
6. Documentar cada decisão em 00_foundation/decision-log.md.

## Como alimentar com pesquisa
Anexar fatos verificados e fichas de referência. Nunca pedir “faça igual ao site X”. Pedir análise de princípios transferíveis e soluções originais.