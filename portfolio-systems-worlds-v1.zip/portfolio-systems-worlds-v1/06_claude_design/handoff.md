# Handoff — do style frame ao código

## Entrega por tela
- Link/frame desktop, tablet e mobile.
- Conteúdo real ou placeholder rotulado.
- Grid, margens, breakpoints, escala tipográfica.
- Cores semânticas e tokens.
- Assets exportados com licença, formato, resolução e alt.
- Componentes e variantes.
- Estados hover, focus, active, disabled, loading, error, empty.
- Motion storyboard com duração, easing, trigger e fallback.
- Critérios de aceite e riscos conhecidos.

## Entrega por componente
Nome, responsabilidade, props, slots, semântica, comportamento de teclado, estados, tokens, responsividade, testes e exemplos de uso.

## Entrega por efeito
ID, intenção, trigger, início/fim, timing, layers, custo de render, interrupção, cleanup, reduced motion, fallback sem JS, fallback sem WebGL.

## Entrega por case
Dados preenchidos no schema; links e permissões; imagens com metadados; copy revisada; diagramas e resultados com fonte.

## Checklist antes de codar
- O design foi testado em 390px?
- O CTA é visível sem animação?
- Existe fallback estático para canvas?
- O texto é selecionável e semântico?
- A marca é legível em 16px?
- Há orçamento de performance?
- As imagens e fontes são legais para uso?

## Critério de aceite do handoff
Um desenvolvedor consegue implementar a tela sem adivinhar hierarquia, comportamento de interação, estado de erro, mobile ou semântica. Ambiguidades ficam registradas como questões, não como decisões implícitas.