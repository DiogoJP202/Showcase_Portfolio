# Template — Nota, ensaio ou experimento pessoal

**Título:** [claro e autoral]  
**Tipo:** note / essay / experiment / collection  
**Publicado em:** [data real] · **Atualizado em:** [data real]  
**Tags:** [2–5 termos] · **Estado:** rascunho / publicado

## Por que escrevi isto?
Uma motivação concreta, não uma introdução genérica.

## A ideia
Texto com voz pessoal, observações, imagens próprias, links com contexto.

## O que aprendi / mudei de ideia?
Uma conclusão ou pergunta aberta.

## Referências
Fontes, créditos, materiais e links.

## Próximo passo
Experimento, leitura ou continuação opcional.

## Notas de publicação
Verificar privacidade, direitos de foto, legibilidade, alt, mobile, links e tradução.