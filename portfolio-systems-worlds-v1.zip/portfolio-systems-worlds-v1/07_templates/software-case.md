# Template — Case de Software

> Copiar para cada projeto real. Remover instruções antes de publicar. Não inventar métricas.

## [Nome real do projeto]
**Resumo de uma linha:** [problema resolvido + contribuição]  
**Papel:** [sua responsabilidade exata] · **Período:** [datas verificadas]  
**Stack:** [tecnologias realmente usadas] · **Status:** [produção / protótipo / encerrado]

### 1. Contexto
Quem era o público? Qual era o problema? Por que isso importava?

### 2. Restrições
Prazo, equipe, legado, requisitos de segurança, escala, custo, acessibilidade, compatibilidade.

### 3. Minha contribuição
O que você projetou, implementou, revisou ou coordenou? O que foi feito por outras pessoas?

### 4. Decisões arquiteturais
| Decisão | Alternativas | Por que escolhi | Trade-off |
| --- | --- | --- | --- |
| [real] | [real] | [evidência] | [limitação] |

### 5. Implementação
Diagrama de arquitetura, fluxo de dados, escolhas de API, UI, testes e observabilidade. Sanitizar informações confidenciais.

### 6. Obstáculos e iterações
Problemas inesperados, debugging, feedback e correções.

### 7. Resultados
**Alegação:** [resultado]  
**Evidência:** [link, medição ou observação verificável]  
**Limitações:** [o que não foi medido]

### 8. Aprendizados
O que faria diferente? O que esse projeto demonstra?

### 9. Mídia e links
Screenshot real, alt, legenda, crédito, demo, repositório (se público), documentação.

### 10. Revisão
[ ] fatos [ ] direitos [ ] acessibilidade [ ] links [ ] tradução [ ] data.