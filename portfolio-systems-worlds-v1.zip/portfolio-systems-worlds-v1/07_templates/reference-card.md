# Template — Ficha de referência visual

**Autor/site:** [nome]  
**URL:** [link] · **Região:** [país] · **Acesso:** [data]  
**Tipo:** developer / designer / studio / game / editorial

## Observações verificáveis
- Hierarquia da primeira tela:
- Navegação:
- Tipografia e grid:
- Uso de imagem:
- Motion:
- Cases:
- Mobile:
- Acessibilidade e performance observadas:

## Padrões transferíveis (não copiar)
1. Princípio:
2. Por que funciona:
3. Como reinterpretar de modo original:
4. Risco:

## Hipóteses a testar
[hipótese] → [teste] → [critério].

## Pontuação 1–5
Clareza, originalidade, tipo, conteúdo, motion, mobile, performance, personalidade, manutenção.

## Direitos e créditos
Não salvar/copiar assets sem permissão. Link para fonte original. Separar fato de opinião.