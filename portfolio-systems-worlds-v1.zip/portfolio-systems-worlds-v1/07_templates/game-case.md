# Template — Case de GameDev

## [Nome real do jogo/protótipo]
**Hook:** [uma frase que explica a experiência]  
**Gênero:** [real] · **Plataforma:** [real] · **Engine:** [real]  
**Estado:** [ideia / protótipo / demo / publicado] · **Meu papel:** [exato]

### Gameplay em primeiro lugar
Inserir vídeo curto real com legenda, poster e transcrição. Não usar concept art como prova de gameplay.

### Loop principal
O jogador faz [ação] para alcançar [objetivo] sob [restrição]. Qual é o diferencial?

### Mecânicas
Descrever cada mecânica, protótipos, testes, ajustes e resultado observado.

### Ferramentas e engenharia
Engine, linguagens, sistemas, shaders, ferramentas internas, otimizações, decisões técnicas.

### Iterações
Versão inicial → feedback → mudança → impacto. Capturas de evolução quando possível.

### Papel e colaboração
O que foi seu, de colaboradores e de assets externos? Créditos e licenças.

### Desafios
Performance, UX, level design, física, IA, narrativa, arte, escopo.

### Jogue / assista / código
Links com requisitos, plataforma, tamanho e avisos de compatibilidade.

### Aprendizados e próximo passo
O que evoluiu e o que pretende explorar?

### Checklist
[ ] vídeo real [ ] créditos [ ] status honesto [ ] controles acessíveis [ ] poster [ ] links.