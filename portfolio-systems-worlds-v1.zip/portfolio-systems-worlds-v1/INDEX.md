# Índice navegável

## Fundação
- [Visão e norte criativo](00_foundation/vision.md)
- [Princípios de produto e anti-padrões](00_foundation/principles.md)
- [Escopo, hipóteses e limites](00_foundation/scope-assumptions.md)
- [Decisões e perguntas abertas](00_foundation/decision-log.md)

## Estratégia
- [Audiências, jobs-to-be-done e métricas](01_strategy/audiences.md)
- [Narrativa, voz e arquitetura de marca](01_strategy/brand-narrative.md)
- [Estratégia de conteúdo e cases](01_strategy/content-strategy.md)
- [Framework de benchmarking](01_strategy/benchmarking.md)

## Experiência
- [Arquitetura de informação e rotas](02_experience/information-architecture.md)
- [Jornadas, wireframes e navegação](02_experience/user-journeys.md)
- [Transições entre os mundos](02_experience/crossworld.md)
- [Acessibilidade e UX inclusiva](02_experience/accessibility.md)

## Direção de arte
- [Sistema de identidade compartilhada](03_art_direction/master-brand.md)
- [Software / The Architect](03_art_direction/software.md)
- [GameDev / The Worldbuilder](03_art_direction/gamedev.md)
- [Personal / The Observer](03_art_direction/personal.md)
- [Gramática de movimento](03_art_direction/motion.md)
- [Tokens e especificações](03_art_direction/design-tokens.md)

## Engenharia
- [Arquitetura técnica](04_engineering/architecture.md)
- [Monorepo e estrutura](04_engineering/repository-structure.md)
- [Modelos de conteúdo](04_engineering/content-model.md)
- [Renderização e performance](04_engineering/performance.md)
- [SEO, internacionalização e analytics](04_engineering/seo-i18n-analytics.md)
- [Segurança, privacidade e licenças](04_engineering/security-privacy.md)
- [ADRs](04_engineering/ADRs.md)

## Entrega e operação
- [Roadmap por fases](05_delivery/roadmap.md)
- [Backlog priorizado](05_delivery/backlog.md)
- [Critérios de aceite](05_delivery/quality-gates.md)
- [Plano de testes](05_delivery/test-plan.md)
- [Checklist de lançamento](05_delivery/launch-checklist.md)

## Claude Design e handoff
- [Prompts prontos](06_claude_design/prompt-pack.md)
- [Rubrica de revisão](06_claude_design/review-rubric.md)
- [Handoff para desenvolvimento](06_claude_design/handoff.md)

## Modelos
- [Case de software](07_templates/software-case.md)
- [Case de jogo](07_templates/game-case.md)
- [Página pessoal e escrita](07_templates/personal-entry.md)
- [Ficha de referência](07_templates/reference-card.md)

## Pesquisa e visuais
- [Status da pesquisa e incorporação](08_research/README.md)
- [Referências e fontes](08_research/references.md)
- [Showcase visual navegável](09_visuals/showcase.html)
- [Mapa do ecossistema](09_visuals/ecosystem.svg)
- [Wireframes conceituais](09_visuals/wireframes.svg)
- [Storyboards de motion](09_visuals/motion-storyboard.svg)

## Recomendações de leitura por perfil
**Direção de arte:** visão → master-brand → 3 direções → motion → showcase → rubrica.  
**Engenharia:** arquitetura de informação → arquitetura técnica → performance → modelos → ADRs → QA.  
**Conteúdo:** audiências → narrativa → estratégia de conteúdo → templates → pesquisa.  
**Execução:** roadmap → backlog → quality gates → launch.