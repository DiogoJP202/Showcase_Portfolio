# Systems & Worlds — Documentação de produto, experiência e engenharia

**Versão:** 0.1.0 · **Data-base:** 13/11/2026 · **Idioma:** português (pt-BR)  
**Status:** foundation / pré-descoberta · **Proprietário:** criador do portfólio  
**Tagline provisória:** *I build systems. I create worlds. I document the journey.*

## Comece por aqui
Este pacote é a base estratégica, visual, técnica e operacional para um ecossistema de **três portfólios autorais**: Software (The Architect), GameDev (The Worldbuilder) e Pessoal (The Observer). Não é um template pronto; é um conjunto de decisões, hipóteses, protótipos visuais, especificações, prompts e critérios para produzir experiências digitais de alto nível.

**Abrir primeiro:** `09_visuals/showcase.html` para ver os três territórios visuais em um navegador; depois `INDEX.md` para navegar pela documentação.

## O que está definido
- Três experiências distintas com assinatura de marca comum.
- Uma entrada acessível, com acesso direto aos projetos profissionais.
- Direções criativas: Kinetic Editorial + Precision Engineering; Interactive Game Atlas + Cinematic Fantasy; Contemporary Japanese Editorial + Digital Garden.
- Animação como linguagem narrativa, não como barreira de navegação.
- Base técnica única inicialmente, com possibilidade de separar aplicações posteriormente.
- Conteúdo real, métricas verificadas, acessibilidade e performance como requisitos de produto.

## O que NÃO está definido
- Nome definitivo da marca; domínio; identidade final; fontes licenciadas; seleção de projetos; resultados de pesquisa externa; stack final; estilo visual aprovado.
- Os SVGs e o HTML são **explorações originais**, não telas finais aprovadas.
- Não foram auditados o GitHub, LinkedIn, currículo, portfólio atual ou resultados da pesquisa profunda nesta versão. O material da pesquisa em andamento precisa ser incorporado com fontes e data em `08_research/`.

## Organização
`00_foundation/` visão e decisões; `01_strategy/` público, narrativa, conteúdo; `02_experience/` IA e jornadas; `03_art_direction/` estilos, motion, tokens; `04_engineering/` arquitetura e modelos; `05_delivery/` roadmap, backlog, QA; `06_claude_design/` prompts e handoff; `07_templates/` modelos reutilizáveis; `08_research/` ingestão e referências; `09_visuals/` protótipos e diagramas.

## Como usar
1. Validar posicionamento e público em 01_strategy.
2. Escolher e testar as direções visuais com o showcase e prompts do Claude Design.
3. Selecionar 3–5 projetos reais para os primeiros cases; registrar evidências.
4. Executar uma prova de conceito de hero e transição com orçamento de performance.
5. Implementar a experiência profissional primeiro, sem bloquear a arquitetura dos demais mundos.
6. Reavaliar todas as hipóteses em marcos de decisão.

## Princípios de integridade
Sem depoimentos, métricas, cargos, clientes, resultados, jogos lançados ou conquistas inventadas. Referências visuais são inspiração, não autorização para copiar layouts ou assets. Todo uso de fonte, imagem, áudio e código de terceiros exige revisão de licença e atribuição.

Consulte `CHANGELOG.md` para evolução e `00_foundation/decision-log.md` para pendências.