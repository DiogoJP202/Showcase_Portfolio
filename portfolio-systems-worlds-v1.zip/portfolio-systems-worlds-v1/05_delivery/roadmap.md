# Roadmap — da pesquisa ao lançamento

## Estratégia
Trabalhar em **fases com gates**, não em calendário rígido. Prazos dependem do volume de conteúdo, assets e complexidade do atlas. Estimativas abaixo são orientativas para trabalho individual.

| Fase | Objetivo | Entregáveis | Gate |
| --- | --- | --- | --- |
| 0 — Discovery | verdade do autor e repertório | inventário, pesquisa integrada, audiência, casos selecionados | 3 cases viáveis |
| 1 — Art direction | escolher identidade | 3×3 style frames, moodboards, tokens preliminares | clareza + originalidade |
| 2 — Motion POC | provar assinatura | hero Software, transição, poster Games, reduced motion | performance e a11y |
| 3 — Work MVP | lançar prova profissional | /work, cases, contato, SEO, QA | pronto para recrutador |
| 4 — Games v1 | catálogo de jogos | /games, cases, vídeos, fallback | conteúdo acessível |
| 5 — Personal v1 | voz autoral | /about, notas, now | identidade coerente |
| 6 — Immersive | elevar GameDev e conexões | atlas opcional, efeitos avançados | não degradar vitals |
| 7 — Polish | refinar e medir | analytics, correções, conteúdo, documentação | revisão de uso real |

## Fase 0 — Discovery (referência: 1–2 semanas)
Coletar links e materiais; mapear projetos; avaliar direitos; incorporar relatório de pesquisa; definir público prioritário. **Não avançar com design final se não houver material real suficiente.**

## Fase 1 — Art direction (1–3 semanas)
Claude Design gera territórios, style frames e versões mobile. Avaliação com rubrica e 3–6 pessoas. Decidir tipografia, paletas, grid, assinatura de movimento e limites.

## Fase 2 — Provas de conceito (1–2 semanas)
Construir somente as interações mais arriscadas: headline cinética, morph da marca, poster → atlas. Medir em mobile e reduced motion. Descartar efeito que não agrega.

## Fase 3 — Work MVP (2–5 semanas)
Design system mínimo, páginas, cases, SEO, testes, analytics mínimos e publicação. Esse marco já deve ser útil como portfólio independente.

## Fases 4–6
Expandir sem quebrar rotas e conteúdo existentes. GameDev catálogo antes do atlas. Pessoal pode começar com notas estáticas e evoluir.

## Gestão de escopo
Classificar tudo em P0 (essencial), P1 (diferencial) e P2 (experimento). Nunca atrasar P0 por P2. Definir limite de WIP de 2–3 tarefas e uma revisão semanal de decisões.

## Marcos de aceite
M0: conteúdo e objetivos verificados. M1: direção visual aprovada. M2: POC passa QA. M3: Work publicado. M4: Games/Personal publicados. M5: atlas opcional sem regressão.