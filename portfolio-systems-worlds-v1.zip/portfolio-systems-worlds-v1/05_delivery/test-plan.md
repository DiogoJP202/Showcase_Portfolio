# Plano de testes

## Pirâmide
**Unit:** schemas, formatadores, helpers, filtros, motion settings.  
**Component:** navegação, cards, menus, diálogos, toggles.  
**E2E:** jornada de recrutador, case profundo, troca de mundo, catálogo Games, contato, idiomas.  
**Visual:** snapshots de heroes, cards, cases, mobile e reduced motion.  
**Performance:** Lighthouse CI + laboratório manual + vitals em produção.

## Casos E2E prioritários
1. Abrir /work, localizar CTA, entrar em case e voltar.
2. Abrir /games sem WebGL e encontrar todos os jogos.
3. Alternar modo imersivo/catálogo sem perder seleção.
4. Abrir /about/notes/[slug] diretamente.
5. Navegar por teclado desde skip link até footer.
6. Usar reduced motion e confirmar ausência de movimento espacial.
7. Abrir página com JS lento e ler conteúdo crítico.
8. Testar idioma inexistente e 404.
9. Compartilhar URL de case e verificar título/preview.
10. Testar links externos e contato.

## Matriz
- Viewports: 320, 375, 768, 1024, 1440 e ultrawide.
- Navegadores: Chromium, Firefox, WebKit/Safari.
- Entrada: mouse, touch, teclado, leitor de tela.
- Preferências: reduced motion, dark/light quando aplicável, zoom 200/400%.
- Rede: Wi-Fi, 4G simulado, offline/erro.
- GPU: WebGL sim/não, DPR reduzido.

## Usabilidade
Teste de 5 segundos (identidade e função); tarefa de 45 segundos (encontrar case e contato); leitura de case (explicar decisão); exploração de games (encontrar gameplay). Registrar tempo, confusões e citações dos participantes.

## Automação
Executar lint/typecheck/unit em PR; Playwright smoke e axe no preview; Lighthouse em páginas representativas; screenshots por tema. Revisão manual antes do lançamento.

## Registro de bugs
Severidade, reprodução, ambiente, screenshot/vídeo, impacto em usuário, causa e correção. Priorizar bloqueios de conteúdo, a11y e navegação sobre polish cosmético.