# Checklist de lançamento e operação

## Conteúdo
- [ ] Nome, função e links confirmados.
- [ ] Projetos selecionados com direitos e papel individual.
- [ ] Cases revisados por factualidade.
- [ ] Screenshots reais, alt text e créditos.
- [ ] Nenhum placeholder de produção.
- [ ] Contato testado.

## Design e UX
- [ ] Três mundos distinguíveis.
- [ ] CTA direto em todos os heroes.
- [ ] Navegação global e breadcrumbs.
- [ ] Layout mobile completo.
- [ ] Motion reduzido.
- [ ] Fallback de 3D e mídia.

## Engenharia
- [ ] Build reproduzível.
- [ ] CI e testes passando.
- [ ] Sem segredos no repositório.
- [ ] Headers/CSP revisados.
- [ ] Links e 404 verificados.
- [ ] Web Vitals medidos.
- [ ] Imagens e fontes otimizadas.

## SEO e publicação
- [ ] Domínio e HTTPS.
- [ ] Canonical, title, description, OG.
- [ ] Sitemap/robots.
- [ ] Hreflang se multilíngue.
- [ ] Analytics/consentimento revisados.
- [ ] Search Console configurado.
- [ ] Plano de rollback.

## Pós-lançamento
- [ ] Monitorar erros e vitals nas primeiras 72h.
- [ ] Fazer teste com 3–5 visitantes reais.
- [ ] Corrigir problemas de compreensão antes de adicionar efeitos.
- [ ] Revisão mensal de conteúdo e links.
- [ ] Registrar aprendizados no decision log.