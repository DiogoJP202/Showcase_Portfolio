# Quality gates — critérios objetivos

## Gate A — Estratégia
- [ ] Público primário e secundário definidos.
- [ ] 3–5 cases com autoria, problema e evidências.
- [ ] Conteúdo sensível e direitos revisados.
- [ ] Narrativa não contradiz currículo/GitHub.

## Gate B — Art direction
- [ ] Três estilos distintos sem virar três templates.
- [ ] Marca comum reconhecível em preto-e-branco.
- [ ] Hero legível em 5 segundos.
- [ ] Desktop e mobile apresentados.
- [ ] Referências atribuídas; nenhum asset copiado.
- [ ] Rubrica média ≥4/5 em clareza, coerência e originalidade (meta interna).

## Gate C — Motion POC
- [ ] CTA disponível antes da conclusão da animação.
- [ ] Sem scroll hijacking ou foco perdido.
- [ ] Reduced motion funcional.
- [ ] Teste em dispositivo médio.
- [ ] Cena 3D não está no bundle inicial fora de /games.

## Gate D — Produto
- [ ] Todas as rotas essenciais funcionam por URL direta.
- [ ] Cases possuem papel, problema, decisões e prova.
- [ ] Navegação keyboard-only.
- [ ] Texto e vídeo acessíveis.
- [ ] Links e formulários funcionam.
- [ ] Estados vazios/erro/loading tratados.

## Gate E — Performance
- [ ] LCP p75 mobile alvo ≤2,5 s.
- [ ] INP p75 alvo ≤200 ms.
- [ ] CLS p75 alvo ≤0,1.
- [ ] Sem long tasks causadas por efeitos decorativos.
- [ ] Bundle e imagens auditados.

## Gate F — Publicação
- [ ] Metadados e sitemap.
- [ ] Segurança, licenças e privacidade.
- [ ] Analytics mínimos com eventos corretos.
- [ ] Monitoramento e rollback.
- [ ] Revisão final de ortografia e traduções.

**Regra:** falha em acessibilidade, conteúdo falso ou navegação bloqueada é impeditiva. Efeito visual pode ser removido sem comprometer lançamento.