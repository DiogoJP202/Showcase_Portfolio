# Backlog priorizado

## P0 — obrigatório para valor real
| ID | História / tarefa | Aceite |
| --- | --- | --- |
| P0-01 | Como visitante, entendo identidade em 5 s | teste de compreensão |
| P0-02 | Como recrutador, abro cases rapidamente | CTA e links diretos |
| P0-03 | Como engenheiro, vejo decisões e trade-offs | ≥3 cases com prova |
| P0-04 | Como visitante, navego sem mouse | teclado completo |
| P0-05 | Como usuário sensível, reduzo movimento | sem motion obrigatória |
| P0-06 | Como visitante mobile, leio tudo | 320px e touch |
| P0-07 | Como visitante, encontro contato | links funcionais |
| P0-08 | Como autor, atualizo cases sem alterar layout | schema e templates |
| P0-09 | Como crawler, leio conteúdo crítico | HTML e metadados |
| P0-10 | Como usuário sem WebGL, vejo jogos | catálogo e poster |

## P1 — diferencial de identidade
| ID | Tarefa | Aceite |
| --- | --- | --- |
| P1-01 | Hero tipográfico cinético | não bloqueia CTA |
| P1-02 | Marca metamórfica | três estados coerentes |
| P1-03 | Transição entre mundos | <500 ms preferencialmente |
| P1-04 | Cases com diagramas editoriais | legíveis e responsivos |
| P1-05 | Página pessoal como digital garden | notas e tags |
| P1-06 | Galeria de games com motion leve | fallback |
| P1-07 | OG images por mundo | previews coerentes |
| P1-08 | Laboratório de experimentos | isolado do core |

## P2 — após validação
Atlas 3D, câmera cinematográfica, partículas, morph avançado, mini-experimentos, coleções com backlinks, easter eggs, trilha sonora opt-in.

## Critério de priorização
Impacto na compreensão (30%), prova de competência (25%), originalidade (20%), esforço (15%), risco de performance (10%). Ajustar após audiência definida.

## Definition of Ready
História tem público, objetivo, design ou wireframe, conteúdo real, estados, fallback, métricas, critérios de aceite.

## Definition of Done
Implementado; testado em desktop/mobile; teclado; reduced motion; SEO quando aplicável; sem regressão de performance; documentação e assets com direitos revisados.