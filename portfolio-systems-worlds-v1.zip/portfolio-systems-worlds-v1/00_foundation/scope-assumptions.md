# Escopo, hipóteses, dependências e exclusões

## Escopo v1
Landing central com acesso aos três mundos; experiência profissional completa com home, índice de projetos, 3–5 cases, sobre, contato; GameDev com catálogo e ao menos um projeto detalhado; Personal com manifesto, timeline/now e entradas selecionadas; laboratório de experimentos opcional.

## Escopo v1.5 / v2
Atlas 3D completo para GameDev, transições cinematográficas entre mundos, conteúdos dinâmicos avançados, microexperiências interativas e localizações adicionais. Só após medir performance e validar conteúdo.

## Hipóteses (não fatos)
H01: o público profissional valoriza cases profundos mais que efeitos.  
H02: um hero cinético com CTA visível aumenta lembrança sem reduzir compreensão.  
H03: a exploração GameDev cria diferencial quando há fallback de catálogo.  
H04: uma identidade editorial pessoal revela repertório sem confundir a proposta profissional.  
H05: uma aplicação única com bundles separados será suficiente no início.  
H06: inglês como idioma inicial pode ser útil para alcance internacional, mas requer validação de objetivos.

## Dependências reais pendentes
- URL do portfólio atual e inventário do GitHub.
- Currículo e histórico que o autor queira publicar.
- Seleção de projetos, permissões de divulgação, imagens, vídeos e métricas verificáveis.
- Resultado integral da pesquisa profunda de portfólios do Brasil, exterior, Japão e Ásia.
- Domínio e estratégia de idiomas.
- Disponibilidade de tempo e prioridades do autor.
- Decisão sobre fotos pessoais e nível de exposição pública.

## Fora de escopo por padrão
E-commerce, login de visitantes, comentários públicos, coleta extensiva de dados, CMS complexo, multilíngue integral antes da tradução revisada, multiplayer, jogo completo embutido no site.

## Premissas de custo
Priorizar hospedagem estática/edge, assets próprios e bibliotecas consolidadas. Serviços externos e custos de produção 3D serão estimados depois de protótipos, nunca assumidos como gratuitos.

## Riscos
R01: efeito visual engole narrativa → gate de conteúdo antes do motion.  
R02: 3D compromete mobile → fallback e lazy loading.  
R03: estilos divergem demais → assinatura comum documentada.  
R04: conteúdo insuficiente → curadoria e cases menores com honestidade.  
R05: escopo cresce → fases e critérios de saída.  
R06: dependência de ferramenta generativa → handoff detalhado e revisão humana.