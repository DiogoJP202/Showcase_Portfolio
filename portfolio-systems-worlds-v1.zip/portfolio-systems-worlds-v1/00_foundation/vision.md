# Visão: três mundos, uma assinatura

## Tese
Um portfólio excelente não é um inventário de cards. É uma **demonstração de pensamento, execução e personalidade**. O ecossistema deve gerar uma primeira impressão memorável, seguida de prova objetiva de capacidade e uma experiência de navegação fluida.

**North star:** quando alguém terminar a visita, deve conseguir dizer: “essa pessoa sabe construir sistemas, pensa em experiências e tem um ponto de vista criativo próprio”.

## Os três mundos
| Mundo | Papel narrativo | Promessa | Emoção |
| --- | --- | --- | --- |
| Software — The Architect | construir sistemas | clareza de decisões e qualidade de execução | confiança, precisão |
| GameDev — The Worldbuilder | criar mundos | inventividade, mecânicas e domínio do processo | curiosidade, imersão |
| Personal — The Observer | documentar a jornada | identidade, referências, escrita e experimentação | proximidade, descoberta |

A marca central pode ser *Systems & Worlds*, mas o nome é provisório e sujeito a validação. A tagline em inglês também é uma hipótese.

## Como reconhecemos sucesso
**Primeiros 5 segundos:** é claro quem é o autor e por que vale explorar.  
**Primeiros 30 segundos:** existe um caminho óbvio para projetos, contexto e contato.  
**Primeiros 3 minutos:** pelo menos um case revela decisões concretas e qualidade técnica.  
**Visita aprofundada:** o usuário encontra personalidade, detalhes e caminhos de exploração sem perder o controle.

## O paradoxo a resolver
Criatividade extrema e legibilidade não são inimigas. A solução é **profundidade progressiva**:
- camada 1: hero memorável e navegação direta;
- camada 2: projetos, contexto e resultados acessíveis sem fricção;
- camada 3: interações, detalhes, easter eggs e experiências imersivas optativas.

## Promessa para cada audiência
Recrutadores encontram fatos e contato rapidamente. Engenheiros encontram decisões, arquitetura e trade-offs. Estúdios e times de jogos encontram mecânicas, processo e material jogável. Pessoas curiosas encontram pensamento e repertório.

## Não objetivos
Não virar uma rede social, CMS complexo ou engine de jogo completa. Não transformar cada clique em animação obrigatória. Não priorizar um prêmio de design sobre a comunicação de competências. Não preencher vazios de conteúdo com ficção.

## Hipótese de experiência
Três estilos radicalmente distintos, conectados por um símbolo mutável, linguagem de navegação e assinatura de qualidade. A unidade vem do **comportamento e do pensamento**, não da repetição literal de cor e layout.

## Validação
Antes de implementar, entrevistar informalmente 3–5 pessoas de perfis distintos, testar hero em 5 segundos e navegação em 60 segundos, comparar entendimento do posicionamento e capacidade de encontrar projetos.