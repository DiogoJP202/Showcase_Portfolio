# Decision log — decisões, propostas e perguntas

| ID | Decisão / hipótese | Estado | Revisão |
| --- | --- | --- | --- |
| D-001 | Três experiências com identidade comum | direção acordada conceitualmente | após moodboards |
| D-002 | Nome “Systems & Worlds” | provisório | naming |
| D-003 | Começar pelo portfólio profissional | recomendado | após inventário |
| D-004 | Domínio único com rotas /work, /games, /about, /lab | recomendado | arquitetura |
| D-005 | Uma aplicação com isolamento de bundles | recomendado | POC |
| D-006 | Atlas GameDev com modo catálogo | princípio definido | POC |
| D-007 | Movimento reduzido e fallback estático | requisito | sempre |
| D-008 | Conteúdo em MDX estruturado | candidato | validação técnica |
| D-009 | Next.js + TypeScript + CSS tokens | candidato | spike |
| D-010 | Identidade japonesa editorial no pessoal | direção exploratória | validação cultural/visual |

## Perguntas prioritárias
1. Quais 3–5 projetos comprovam melhor capacidade técnica e impacto?
2. Quem é o público principal: recrutadores internacionais, clientes, estúdios, comunidade?
3. A marca principal deve usar nome pessoal, Systems & Worlds ou combinação?
4. Qual é a língua principal e quais páginas exigem tradução?
5. Qual o nível de exposição de fotos, voz e história pessoal?
6. Existem jogos jogáveis, vídeos, gifs e breakdowns técnicos publicáveis?
7. Quanto tempo real existe para produção de assets 3D/ilustração?
8. Qual conceito tem melhor equilíbrio de clareza, originalidade e manutenção?

## Regra de decisão
Cada decisão irreversível precisa de: alternativas consideradas, evidência, consequência técnica, impacto de manutenção e data de revisão. Os ADRs de engenharia estão em 04_engineering/ADRs.md.