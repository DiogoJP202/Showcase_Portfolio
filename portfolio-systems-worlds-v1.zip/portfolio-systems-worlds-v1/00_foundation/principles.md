# Princípios e anti-padrões

## 1. WOW com propósito
Toda animação deve servir a pelo menos uma função: orientar, revelar hierarquia, contar história, fornecer feedback ou transmitir materialidade. Caso contrário, é decoração opcional e deve poder ser removida sem perda de compreensão.

## 2. Conteúdo primeiro, espetáculo depois
Projetos reais, decisões, evidências, resultados e aprendizados precedem efeitos. O hero não pode ocultar o CTA de trabalhos nem depender de carregamento 3D para mostrar informação crítica.

## 3. Três linguagens, um autor
Software: precisão. Games: exploração. Pessoal: contemplação. A assinatura comum pode ser um símbolo, um padrão de transição, uma voz editorial e o mesmo nível de acabamento.

## 4. Acessível por construção
Navegação por teclado, foco visível, semântica, contraste, redução de movimento, conteúdo alternativo a cenas e formulários acessíveis não são extras de pós-lançamento.

## 5. Performance é parte da estética
Movimento fluido exige escolhas técnicas: CSS transform/opacity quando possível, 3D opt-in ou lazy, assets comprimidos, fontes com fallback, monitoramento de Core Web Vitals.

## 6. Personalidade sem clichês
Evitar terminal fake, chuva de código, gradientes aleatórios, excesso de glassmorphism, dashboard genérico, cards repetidos, “console.log('hello world')” como identidade e ícones culturais japoneses usados como enfeite.

## 7. Revelar, não esconder
Experimentos podem ser descobertos, mas conteúdo essencial nunca deve depender de caça ao tesouro. Navegação direta, breadcrumbs e rotas compartilháveis.

## 8. Respeitar a autoria
Não copiar portfolios de referência pixel a pixel, não usar assets de jogos sem direitos, não clonar microinterações proprietárias. Referências servem para análise de princípios.

## 9. Sistema que pode evoluir
Conteúdo separado da apresentação, tokens versionados, casos reutilizáveis, isolamento das experiências. Evitar um mega-componente único para três mundos.

## 10. Decisões testáveis
Registrar hipótese, alternativa, custo, critério e data de revisão. A direção final não é escolhida apenas por gosto: também por clareza, originalidade, viabilidade e resultados de teste.

## Anti-padrões de execução
- Scroll hijacking que quebra comportamento nativo.
- Cursor customizado que prejudica usabilidade.
- Preloader longo ou obrigatório.
- Som autoplay.
- 3D bloqueando interação em mobile.
- Textos animados sem respeito a leitores de tela.
- Projetos sem contexto ou prova.
- Dependência de um único dispositivo para compreender o conteúdo.
- Dependência de API externa para renderizar o essencial.