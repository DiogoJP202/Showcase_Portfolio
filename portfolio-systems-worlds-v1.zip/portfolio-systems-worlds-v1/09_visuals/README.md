# Visual explorations

Abrir `showcase.html` localmente no navegador para comparar os três mundos. Os SVGs são vetores originais e podem ser importados em Figma ou ferramentas de apresentação como referências conceituais.

- `styleframe-software.svg`: manifesto cinético + diagrama técnico.
- `styleframe-gamedev.svg`: portal atmosférico + atlas potencial.
- `styleframe-personal.svg`: publicação editorial + papel/tinta.
- `ecosystem.svg`: arquitetura de marca e base compartilhada.
- `wireframes.svg`: hierarquia funcional das três primeiras telas.
- `motion-storyboard.svg`: sequência ilustrativa do hero Software.
- `brand-mark-studies.svg`: seis símbolos geométricos para debate.

**Não são mockups finais** nem substituem protótipos responsivos testados. Os textos dos style frames são conceituais e não representam projetos reais. Não há fotos ou assets externos incluídos.