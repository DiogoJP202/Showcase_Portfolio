# Estratégia de conteúdo: prova antes da interface

## Inventário obrigatório
Para cada projeto: nome real, período, papel individual, equipe, stack, problema, público, decisões, arquitetura, obstáculos, solução, resultado mensurável (se houver), links, capturas, permissão de publicação e aprendizados.

## Pirâmide de conteúdo
**Teaser:** 1 frase com problema + contribuição.  
**Resumo:** contexto, papel, stack e resultado verificável.  
**Case completo:** narrativa com problema, restrições, alternativas, implementação, trade-offs, resultado e retrospectiva.  
**Material de prova:** diagramas, screenshots, vídeos, repositórios e demos.

## Critério para projetos em destaque
Pontuar 1–5: relevância para público, profundidade técnica, contribuição pessoal, prova visual, atualidade e clareza de direitos. Escolher 3–5 para lançamento; diversidade vale mais que quantidade.

## Estrutura de case de software
- Contexto: para quem, por quê, qual problema.
- Meu papel: responsabilidade e limites claros.
- Restrições: tempo, equipe, legado, custo, segurança.
- Decisões: opções, escolha e justificativa.
- Arquitetura: diagrama e fluxo.
- Construção: etapas e obstáculos reais.
- Resultados: números somente se verificáveis; senão resultados qualitativos com evidência.
- Aprendizados: o que faria diferente.
- Próximo passo: demo, código, contato.

## Estrutura de case de jogo
Hook visual e gameplay logo no início; gênero, plataforma, estado, papel, loop principal, mecânicas, ferramentas, iterações, desafios, vídeos, build jogável se houver, aprendizados. Não apresentar concept art como screenshot de jogo final.

## Personal
Notas curtas e ensaios, “now page”, estudos, fotografia própria, coleção de links e laboratório. Etiquetar datas e estágios: rascunho, estudo, publicado.

## Governança
Content source versionado, revisão de fatos e links, alt text, legenda de mídia, política de atualização, redirecionamentos ao mudar slug. Um case não deve depender de dados pessoais de terceiros.

## Entrega mínima de conteúdo antes do design final
Uma bio verificada de 70–100 palavras, três projetos preenchidos em 80% do template, links de contato, 1 página de jogo, 3 entradas pessoais ou uma página “Now” real. Sem isso, usar placeholders claramente marcados.