# Audiências, tarefas e sinais de sucesso

## Segmentos
### Recrutador(a) / hiring manager
**Job:** confirmar nível, stack, experiência, localização/fuso, links e contato rapidamente.  
**Necessidades:** hero claro, currículo acessível, 3 projetos fortes, LinkedIn/GitHub, contato sem fricção.  
**Risco:** abandono por navegação teatral ou textos vagos.  
**Tarefa de teste:** “encontre um projeto relevante e uma forma de contato em menos de 45 segundos”.

### Engenheiro(a) / tech lead
**Job:** avaliar pensamento técnico, arquitetura, trade-offs, debugging e qualidade de entrega.  
**Necessidades:** contexto, diagramas, decisões, limitações, métricas, código quando permitido.  
**Tarefa:** “explique por que uma escolha técnica foi feita e o que foi sacrificado”.

### Estúdio de games / colaborador criativo
**Job:** avaliar sensibilidade de gameplay, prototipagem, ferramentas e contribuição individual.  
**Necessidades:** gameplay visível, vídeo curto, mecânicas, papel, plataformas, estado do jogo.  
**Tarefa:** “encontre um jogo, assista ao gameplay e entenda sua contribuição”.

### Comunidade / pares / pessoas curiosas
**Job:** descobrir repertório, processos, escrita, projetos paralelos.  
**Necessidades:** notas, timeline, laboratório, links de referências, personalidade.  
**Tarefa:** “encontre algo que você não esperava e consiga compartilhá-lo”.

## Hierarquia
Público primário a confirmar. Enquanto não houver evidência, priorizar **clareza profissional**, com trilhas igualmente legítimas para games e pessoal.

## Métricas de produto (propostas, não metas comerciais comprovadas)
- Qualitativas: entendimento em 5 segundos; taxa de sucesso em tarefas; lembrança de identidade após visita.
- Comportamentais: abertura de case, clique para projeto ao vivo/repo, clique de contato, troca entre mundos.
- Técnicas: LCP, INP, CLS, taxa de erros, queda para fallback 3D.
- Não otimizar “tempo no site” isoladamente: fricção pode inflar tempo.

## Plano de validação
Teste com 2 recrutadores, 2 engenheiros e 2 criativos, se possível. Observar sem orientar. Registrar confusões, não apenas elogios. Comparar variante cinética vs. hero estático em tarefa de navegação.