# Benchmarking de portfólios — método de análise

## Objetivo
Aprender com portfólios de desenvolvedores, criativos e estúdios no Brasil, internacionalmente, no Japão e em outros países asiáticos, sem copiar soluções.

## Eixos de avaliação (0–5)
1. Clareza da proposta nos primeiros 5 segundos.
2. Originalidade da direção de arte.
3. Qualidade de tipografia, grid e hierarquia.
4. Narrativa e prova em cases.
5. Motion: intenção, ritmo, fluidez e controle.
6. Usabilidade por teclado e mobile.
7. Performance observável e fallback.
8. Personalidade e memorabilidade.
9. Qualidade de conteúdo real.
10. Manutenção e escalabilidade aparente.

## Como registrar
Para cada referência, usar `07_templates/reference-card.md`: URL, data de acesso, região, screenshots autorizados ou descrição, padrões observados, decisões transferíveis, riscos, licença de assets, pontuação, aplicação possível em cada mundo.

## Separar observação de inferência
**Observação:** “o menu oferece atalho direto para projetos”.  
**Inferência:** “isso talvez reduza fricção”.  
**Teste:** “medir tempo para abrir um case com 5 pessoas”.  
Evitar inferir tecnologia ou resultados sem evidência.

## Referências fornecidas na conversa
- Perfil de Yuta Asakura: https://www.linkedin.com/in/yuta-asakura/
- Perfil de Yusuke Sano: https://www.linkedin.com/in/yusuke-sano-8722631a2/
- URLs mencionadas anteriormente: https://asakurayuta.dev/ e https://yusuke.sn/ — **verificar correspondência, disponibilidade e detalhes antes de citar como estudos de caso**.

## Estado da pesquisa
A pesquisa profunda foi iniciada anteriormente, mas seu relatório integral **não está presente no material disponível para esta compilação**. Portanto, este documento oferece o método e os pontos de ingestão; não inventa ranking, análises ou achados. Ver `08_research/README.md`.