# Narrativa e arquitetura de marca

## Arquétipo proposto
**Builder / Worldbuilder / Observer**: três papéis que revelam uma mesma maneira de pensar. A narrativa deve nascer de projetos reais, não de slogans grandiosos.

## Hierarquia da mensagem
1. Identificação: nome e atuação atual, descritos com precisão.
2. Proposta: o que constrói e qual perspectiva oferece.
3. Prova: projetos, decisões, impacto e material demonstrável.
4. Profundidade: processo, jogos, estudos, escrita e interesses.
5. Convite: contato e colaboração.

## Voz
Tom: curioso, confiante sem arrogância, técnico quando necessário, pessoal quando apropriado. Evitar jargão publicitário (“revolucionário”, “visionário”) e autoelogios sem prova. Frases curtas no hero, conteúdo profundo nos cases.

## Possíveis assinaturas — não aprovadas
- “I build systems. I create worlds. I document the journey.”
- “From robust systems to playable worlds.”
- “Engineering with curiosity. Worlds with intention.”
Escolher com base no repertório real e nos objetivos do autor.

## Elementos de unidade
**Símbolo metamórfico:** mesmo sinal-base em três materiais: wireframe preciso, artefato luminoso, traço de tinta.  
**Navegação:** marcador discreto de mundo atual e acesso universal aos demais.  
**Ritmo:** um padrão de revelação reconhecível, mas com velocidades e texturas distintas.  
**Assinatura editorial:** títulos diretos, explicação do processo e notas de bastidores.

## Naming e domínio
Recomenda-se nome pessoal como autoridade e Systems & Worlds como conceito editorial, até testar alternativas. Não registrar domínio antes de avaliar disponibilidade e conflitos de marca.

## Idiomas
Estruturar desde o início para pt-BR e en-US, mas publicar somente traduções revisadas. Não misturar japonês ornamental sem necessidade semântica. Os textos do showcase são placeholders conceituais.

## Microcopy
Software: “Explore selected work”, “How it was built”, “View architecture”.  
GameDev: “Enter world”, “Watch gameplay”, “Browse all projects”.  
Pessoal: “Field notes”, “Currently exploring”, “A few things about me”.  
Botão global: “Switch worlds” pode funcionar se testado; alternativa mais clara: “Software / Games / About”.