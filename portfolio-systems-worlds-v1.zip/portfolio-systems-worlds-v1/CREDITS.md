# Créditos e direitos

## Material original
Textos, especificações, diagramas SVG e showcase HTML foram produzidos como documentação conceitual para este projeto.

## Terceiros
Nenhuma captura de portfólio, imagem de jogo, fotografia de pessoa, logo de terceiros ou fonte binária está incorporada ao pacote. Referências externas são apenas URLs e leitura sugerida.

## Antes de publicar
Documentar licenças e créditos de fontes, imagens, modelos, áudio, bibliotecas, ícones, texturas e vídeos. Não utilizar imagens de referência como assets finais sem autorização.