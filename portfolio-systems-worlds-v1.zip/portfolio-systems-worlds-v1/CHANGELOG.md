# Changelog

## 0.1.0 — 2026-11-13
- Consolidada a arquitetura conceitual de três experiências sob uma identidade compartilhada.
- Produzidos documentos de produto, UX, direção de arte, engenharia, entrega, prompts e templates.
- Adicionados SVGs originais e showcase HTML exploratório.
- Identificadas decisões em aberto e dependências da pesquisa profunda e inventário real de projetos.
- Nenhuma direção visual foi aprovada como identidade final; nenhum projeto real foi presumido.