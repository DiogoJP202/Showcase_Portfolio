# Jornadas, wireframes funcionais e estados

## Jornada A — recrutador
**Entrada:** link direto /work ou /.  
**0–5 s:** nome, função real e CTA “Selected work”.  
**5–30 s:** três cases selecionados com resumo e tags.  
**30–90 s:** case com papel, decisões, stack e resultados.  
**Saída:** contato / LinkedIn / currículo.

**Critério de sucesso:** sem interação experimental obrigatória. Hero com motion não pode atrasar CTA nem leitura.

## Jornada B — engenharia
**Entrada:** case via busca ou GitHub.  
**Percurso:** problema → arquitetura → alternativas → implementação → trade-offs → evidências → código.  
**Saída:** compartilhar case, entrar em contato ou explorar outro.

## Jornada C — GameDev
**Entrada:** /games.  
**Escolha:** “Explore world” (se suportado) ou “Browse projects”.  
**Percurso imersivo:** ambiente → pontos de interesse → projeto → vídeo/jogo → retorno ao mapa.  
**Percurso catálogo:** cards → filtros simples → case → build/demo.  
**Saída:** contato ou outro mundo.

## Jornada D — pessoal
**Entrada:** /about.  
**Percurso:** manifesto curto → timeline → notas/experimentos → now → contato.  
**Ritmo:** sem pressa, mas sempre navegável por headings e links.

## Wireframe funcional — /work
1. Header: nome / símbolo, mundo atual, outros mundos, contato.
2. Hero: título dominante; subtítulo factual; CTA “View work”; composição técnica decorativa.
3. Featured: três cases editoriais com imagem e tese curta.
4. Approach: como pensa e resolve problemas.
5. About teaser: ponte para /about.
6. Footer: contato, redes, créditos.

## Wireframe funcional — /games
1. Header simples e controle de áudio (desligado por padrão se houver áudio).
2. Hero cinematográfico ou frame estático de fallback.
3. Ação primária “Browse projects”; secundária “Enter world”.
4. Atlas explorável ou catálogo.
5. Featured game: gameplay e papel.
6. Devlog / experimentos.
7. Footer.

## Wireframe funcional — /about
1. Hero editorial com frase autoral.
2. Blocos de história e interesses.
3. Coleção de notas / experiências.
4. Timeline / Now.
5. Links e contato.

## Estados obrigatórios
Loading sem preloader bloqueante; error boundary com retry; empty state honesto; sem WebGL; GPU limitada; JS desabilitado (conteúdo principal SSR); conexão lenta; reduzido movimento; keyboard only; touch; viewport estreita; idioma indisponível; conteúdo ainda não publicado.

## Conteúdo e hierarquia
Todos os wireframes são **esqueletos**, não aprovação de layout. Consultar 09_visuals/wireframes.svg para comparação visual das três primeiras telas.