# Acessibilidade e UX inclusiva

## Referência
Meta: WCAG 2.2 AA como orientação de projeto. Testes automatizados ajudam, mas não substituem navegação manual e usuários reais.

## Requisitos fundamentais
- HTML semântico: nav, main, header, footer, section, headings hierárquicos.
- Link “Pular para conteúdo” visível no foco.
- Todos os controles com rótulo; foco visível e ordem lógica.
- Contraste: texto normal ≥4,5:1; texto grande ≥3:1; componentes de UI ≥3:1 onde aplicável.
- Alvos de toque adequados, estados hover não exclusivos, suporte touch e teclado.
- Respeitar `prefers-reduced-motion`; fornecer controle explícito de efeitos imersivos.
- Não iniciar áudio automaticamente; legendas em vídeos; descrição de conteúdo relevante.
- Imagens com alt text útil; imagens puramente decorativas com alt vazio.
- Não transmitir informação somente por cor, movimento ou som.
- Texto permanece no DOM e legível quando animação falha.
- Formulários com erros associados a campos e mensagens claras.

## 3D e canvas
Canvas é **decorativo ou suplementar**. O mesmo conteúdo essencial deve existir em HTML. Pontos interativos do atlas devem ter equivalentes em lista semântica. Desativar 3D quando WebGL falhar, houver reduced-motion ou dispositivo incapaz.

## Animação de texto
Evitar dividir texto em spans que confundam leitores de tela; manter texto semântico único ou usar aria-hidden apenas na camada visual duplicada, com equivalente acessível.

## Foco após navegação
Em navegação client-side, atualizar título, anunciar contexto quando necessário e posicionar foco no heading. Modais têm focus trap, Escape e retorno de foco.

## Plano de testes
Desktop: teclado completo e NVDA/VoiceOver conforme disponibilidade. Mobile: TalkBack/VoiceOver e toque. Zoom 200%/400%, viewport 320px, alto contraste, reduzir movimento, modo de economia de dados.

## Gate de lançamento
Nenhum bloqueio de teclado, conteúdo oculto sem fallback, mídia sem legenda relevante ou animação obrigatória. Registrar exceções e corrigir antes de divulgar.