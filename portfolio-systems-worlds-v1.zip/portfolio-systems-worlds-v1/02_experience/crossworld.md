# Transições entre mundos — identidade em movimento

## Ideia
Um símbolo geométrico abstrato (três traços que se cruzam em um nó, sujeito a design) muda de **material**, não apenas de cor:
- Software: wireframe vetorial com linhas e nós.
- GameDev: artefato luminoso com volume e partículas contidas.
- Personal: marca de tinta sobre papel.

## Comportamento padrão
Clique em “Games” a partir de “Software”:
1. Feedback imediato no link (0–80 ms).
2. Marca entra em foco e altera material (250–450 ms).
3. Nova página entra com título e conteúdo prioritário (até 500 ms).
4. Foco acessível vai para heading principal; scroll segue comportamento esperado.
5. Em reduced-motion, troca instantânea com crossfade discreto ou sem transição.

## Restrições
Não bloquear navegação até terminar animação; não esconder o destino por >500 ms; não impedir Back/Forward; não reexecutar transição em todas as visitas; não exigir GPU; respeitar preferência do usuário.

## Variante simples (MVP)
CSS transform + opacity do símbolo em 250–350 ms. Sem View Transitions API obrigatória. A identidade pode ser resolvida em SVG e CSS variables.

## Variante avançada (pós-POC)
View Transitions API com fallback; morph SVG e renderização 3D somente se orçamento permitir. Evitar dependência entre rotas e cena WebGL.

## Experimentos
A/B qualitativo: transição simples vs. cinematográfica curta. Perguntas: “Você percebeu que mudou de universo?”, “Conseguiu chegar ao destino sem espera?”, “Foi memorável ou cansativo?”.

## Hand-off
Definir estados start/end, easing, duração, layering, foco, teclado, reduced motion, SSR, cancelamento, fallback e testes automatizados.