# Arquitetura de informação — três mundos, zero becos sem saída

## Modelo proposto: uma aplicação, um domínio, três experiências
| Rota | Função | Acesso principal |
| --- | --- | --- |
| / | entrada editorial com identidade e acesso direto | global |
| /work | home Software | global |
| /work/projects | índice filtrável de cases | Software |
| /work/projects/[slug] | case detalhado | Software |
| /games | home GameDev com seleção de modo | global |
| /games/projects | catálogo acessível | GameDev |
| /games/projects/[slug] | case de jogo | GameDev |
| /about | home Pessoal | global |
| /about/notes | notas / digital garden | Pessoal |
| /about/notes/[slug] | texto / ensaio | Pessoal |
| /lab | protótipos, experimentos e estudos | global opcional |
| /contact | contato e links | global |
| /now | estado atual, opcional | Pessoal |
| /sitemap.xml, /robots.txt | indexação | infraestrutura |

## Entrada global
A home deve informar identidade, três caminhos e **acesso direto a projetos de software**. Não usar “escolha um portal” como etapa obrigatória para recrutadores. Se o usuário chegar via link profundo, o conteúdo deve carregar sem precisar passar pela home.

## Navegação
**Desktop:** marca/assinatura, links Software · Games · Personal, contato, indicador de mundo.  
**Mobile:** navegação direta compacta; menu sem animação obrigatória; CTA principal sempre legível.  
**Cases:** breadcrumb, próximo projeto, link para índice, links externos com rótulos claros.  
**Troca de mundo:** transição curta, opcional e reversível; preservar histórico e foco.

## Convenções
- Slugs legíveis e estáveis.
- Cada rota tem título, descrição, canonical, imagem social e heading único.
- Cards inteiros podem ser links, com foco visível e sem links aninhados.
- Filtros não devem ocultar conteúdo dos mecanismos de busca; usar páginas/rotas estáveis quando necessário.
- Evitar scroll hijack, animação de página que impede botão Voltar, carregamento indefinido e overlays sem fechamento.

## Descoberta progressiva
Camada 1: quem é + trabalho. Camada 2: cases e detalhes. Camada 3: laboratório, easter eggs, atlas 3D, microinterações. A terceira camada nunca contém informações essenciais exclusivas.

## Eventos de navegação a observar
Visita a /work, abertura de case, clique em demo/repo, clique em contato, troca de mundo, escolha do modo catálogo/imersivo, uso de reduzir movimento. Dados agregados, sem rastreamento invasivo.

## Perguntas de validação
Um visitante novo encontra um case em 10 segundos? Um recrutador entende o papel do autor? O atlas pode ser ignorado sem perder informação? O menu funciona com teclado e leitor de tela?