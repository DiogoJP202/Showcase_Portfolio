# Estrutura de repositório e convenções

## Proposta de monorepo leve
```text
portfolio/
├─ apps/
│  └─ web/
│     ├─ app/
│     │  ├─ (global)/page.tsx
│     │  ├─ (work)/work/page.tsx
│     │  ├─ (work)/work/projects/[slug]/page.tsx
│     │  ├─ (games)/games/page.tsx
│     │  ├─ (games)/games/projects/[slug]/page.tsx
│     │  ├─ (personal)/about/page.tsx
│     │  ├─ (personal)/about/notes/[slug]/page.tsx
│     │  ├─ lab/page.tsx
│     │  └─ contact/page.tsx
│     ├─ components/
│     ├─ features/{work,games,personal}/
│     └─ styles/
├─ packages/
│  ├─ design-tokens/
│  ├─ ui-core/
│  ├─ content-schema/
│  └─ analytics/
├─ content/
│  ├─ projects/software/
│  ├─ projects/games/
│  ├─ notes/
│  └─ pages/
├─ public/
│  ├─ media/
│  ├─ posters/
│  └─ worlds/
├─ docs/
├─ scripts/
├─ tests/
└─ package.json
```

## Regras
- Evitar pacote compartilhado para código usado por uma rota só.
- `ui-core` contém semântica e comportamento, não visual rígido.
- Tema por atributo `data-world` e tokens CSS.
- Features de GameDev não são importadas no layout global.
- Dados de conteúdo passam por schema antes de renderizar.
- Arquivos de mídia versionados com naming consistente e créditos.
- Todos os caminhos de navegação usam URLs reais, não estado global efêmero.

## Convenções de naming
`kebab-case` para rotas e assets; `PascalCase` para componentes; `camelCase` para funções; `*.test.ts(x)` unitários; `*.spec.ts` e2e. Slugs não dependem de título traduzido.

## Pull request checklist
Motivo da mudança; screenshots desktop/mobile; teste de teclado; reduced motion; budget de bundle; links e SEO; licenças; regressão visual; nota no changelog quando relevante.

## Branching
Trunk-based com PRs pequenos. Feature flags para atlas/3D. Não colocar experimentos inacabados no caminho principal de produção.

## CI mínima
Lint → typecheck → schema validation → unit → build → Playwright smoke → Lighthouse budget → deploy preview. Visual regression em páginas críticas.

## Documentação viva
Cada decisão técnica significativa vira ADR. Cada novo componente tem estados, variações e a11y. Cada case tem data de atualização e evidências.