# Arquitetura técnica — proposta implementável

## Objetivo
Entregar três experiências distintas com uma base confiável, evitando que a camada imersiva comprometa SEO, acessibilidade, performance ou manutenção.

## Decisão recomendada para a primeira implementação
**Uma aplicação Next.js (App Router) + TypeScript**, organizada por route groups e componentes temáticos, com conteúdo em MDX/arquivos estruturados. **Não é decisão final**: executar spike e comparar com Astro (particularmente para o Personal estático).

### Por que começar unificado?
- Domínio, analytics, SEO, navegação, conteúdo e componentes acessíveis compartilhados.
- Troca entre mundos mais simples e menos manutenção.
- Deploy único no início.
- Isolamento de bundle por rota permite não carregar WebGL fora de /games.

### Quando separar?
Se a experiência GameDev exigir pipeline 3D independente, dependências conflitantes, orçamento de bundle fora da meta ou ciclos de deploy diferentes. Nesse caso, migrar /games para app separada ou subdomínio sem reescrever conteúdo.

## Stack candidata
- Framework: Next.js App Router / React / TypeScript.
- UI: CSS variables + CSS Modules ou Tailwind (escolher uma convenção dominante).
- Conteúdo: MDX + frontmatter/schema Zod; páginas estáticas/ISR conforme necessidade.
- Motion: CSS para microinterações; Motion **ou** GSAP para sequências (escolher por spike).
- 3D opcional: Three.js + React Three Fiber, carregado apenas por interação em /games.
- Imagens: pipeline responsivo com formatos AVIF/WebP, alt text, poster de vídeo.
- Testes: Vitest, Testing Library, Playwright, axe-core e Lighthouse CI.
- Deploy: hosting com suporte a SSR/SSG e cache CDN; provedor a decidir.

## Diagrama lógico
Browser → CDN/edge → HTML pré-renderizado por rota → hydration apenas dos componentes interativos → dados de conteúdo versionados. /games carrega cena opcional após gesto do usuário. Analytics agregados recebem eventos mínimos e não são requisito de renderização.

## Limites de responsabilidade
**Core:** conteúdo, acessibilidade, rotas, metadados, tokens, telemetria.  
**Work:** apresentação de cases, diagramas, componentes técnicos.  
**Games:** catálogo, UI do atlas, renderer opcional.  
**Personal:** notas, timeline, coleções, tipografia editorial.

## Renderização
SSG para landing, índices e cases publicados. SSR só se houver conteúdo realmente dinâmico. Não carregar cliente React para elementos que podem ser HTML/CSS. Importar componente 3D dinamicamente, com poster estático.

## Erros e degradação
Falha de fonte → fallback system; falha de canvas → catálogo; falha de vídeo → poster e transcrição; JS indisponível → navegação e conteúdo críticos em HTML; erro de API de contato → e-mail explícito.

## Dados e privacidade
Sem login e sem banco de dados por padrão. Contato pode ser mailto ou formulário com proteção anti-spam; preferir opção simples até haver necessidade real. Não colocar segredos no cliente.

## Trade-offs
Uma app aumenta acoplamento de dependências se não houver disciplina de bundles. Três apps aumentam custo de deploy, design system e navegação. Revisar após POC de /games e medição real.