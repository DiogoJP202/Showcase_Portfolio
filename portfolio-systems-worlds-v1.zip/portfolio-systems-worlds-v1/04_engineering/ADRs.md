# Architecture Decision Records (ADRs)

## ADR-001 — Uma aplicação inicialmente
**Estado:** proposta. **Contexto:** três mundos, base compartilhada, manutenção individual.  
**Decisão:** iniciar com uma aplicação web e isolamento por rotas.  
**Alternativas:** três aplicações; subdomínios; microfrontends.  
**Consequências:** deploy simples, navegação compartilhada; risco de bundle e acoplamento.  
**Revisitar se:** GameDev exigir pipeline próprio ou bundle vazar para outras rotas.

## ADR-002 — Conteúdo versionado em MDX + schema
**Estado:** proposta.  
**Motivo:** baixo volume inicial, versionamento e revisão técnica.  
**Alternativas:** CMS headless, banco de dados, JSON puro.  
**Consequência:** fácil revisão e baixo custo; editor menos amigável para não desenvolvedores.  
**Revisitar se:** conteúdo colaborativo e publicação frequente exigirem CMS.

## ADR-003 — HTML primeiro, WebGL opcional
**Estado:** princípio.  
**Decisão:** conteúdo e navegação críticos em HTML; cena 3D apenas como enhancement.  
**Consequência:** melhor acessibilidade e robustez; design de fallback obrigatório.

## ADR-004 — Motion por camadas
**Estado:** proposta.  
**Decisão:** CSS para microinterações; escolher uma biblioteca para sequências complexas após POC.  
**Consequência:** menor custo de JS e manutenção; exige disciplina de API.

## ADR-005 — Tokens compartilhados, temas independentes
**Estado:** proposta.  
**Decisão:** base de espaçamento, semântica e estados comum; cores, tipografia e composição por mundo.  
**Consequência:** consistência de UX sem homogeneização visual.

## ADR-006 — Pesquisa e conteúdo não podem ser inventados
**Estado:** princípio.  
**Decisão:** cases só publicados com evidência, autoria e direitos verificados.  
**Consequência:** pode reduzir quantidade de projetos; aumenta credibilidade.

## ADR-007 — Idioma definido pelo público
**Estado:** pendente.  
**Alternativas:** pt-BR primário, en-US primário, multilíngue por prefixo.  
**Decisão futura:** após entrevistas e objetivo profissional.

## ADR-008 — Atlas só após catálogo
**Estado:** proposta.  
**Decisão:** catálogo GameDev primeiro, atlas 3D como segunda camada.  
**Consequência:** garante conteúdo navegável e reduz risco de cronograma.

## Template para novos ADRs
ID, título, data, status, contexto, decisão, alternativas, consequências, critérios de revisão, evidências e links para PRs.