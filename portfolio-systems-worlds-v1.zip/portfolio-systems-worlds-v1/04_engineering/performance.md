# Performance, renderização e orçamento

## Metas de experiência (referência inicial)
- LCP p75 mobile ≤ 2,5 s.
- INP p75 ≤ 200 ms.
- CLS p75 ≤ 0,1.
- Interações fluidas idealmente em 60 fps quando o hardware permitir.
- Primeira navegação funcional antes de qualquer 3D.
Essas são metas, não resultados medidos. Validar em dispositivos e redes reais.

## Orçamentos exploratórios
- JS crítico inicial por rota: alvo ≤250 KB gzip, sujeito a medição e ajuste.
- Cena 3D: **fora do bundle inicial**, carregada por intenção do usuário.
- Imagem hero mobile: poster responsivo e comprimido, idealmente ≤250–350 KB conforme qualidade.
- Fontes: 1–2 famílias principais por mundo, subsets, `font-display: swap`.
- Evitar vídeo autoplay pesado na dobra; poster primeiro.

## Estratégia de carregamento
1. HTML com conteúdo crítico e CTA.
2. CSS crítico e fontes essenciais.
3. Imagens responsivas com prioridades corretas.
4. Hydration de controles necessários.
5. Motion decorativo após first paint.
6. WebGL/3D após interação e verificação de capacidade.

## 3D e fallback
- Poster estático sempre presente e significativo.
- Detecção de suporte WebGL sem fingerprinting invasivo.
- Limitar DPR/render resolution em dispositivos modestos.
- Usar assets glTF otimizados, texturas comprimidas, geometria simplificada, draw calls contidas.
- Pausar render quando invisível; desmontar cena ao sair.
- Respeitar reduced motion e “browse projects” como caminho equivalente.

## CSS e animações
Preferir transform/opacity. Evitar animações de top/left/width, filtros blur gigantes, box-shadow animado em grandes áreas. Usar IntersectionObserver com cleanup; evitar múltiplos scroll listeners concorrentes.

## Teste de laboratório
Perfis: desktop moderno; notebook médio; Android intermediário; iPhone recente e antigo quando possível. Rede 4G simulada, CPU throttling, warm/cold cache, zoom e redução de movimento.

## Observabilidade
Core Web Vitals por rota e dispositivo; erros JS; falhas de WebGL; tempo de carregamento de assets; cliques de fallback. Não registrar identificadores desnecessários.

## Regras de bloqueio
Se LCP ou INP piorarem substancialmente por causa de um efeito, remover/simplificar o efeito antes de otimizar por microajustes. Se /games não renderizar em dispositivo médio, lançar catálogo antes do atlas.

## Referências técnicas para consulta
web.dev/vitals; web.dev/learn/performance; developer.mozilla.org (prefers-reduced-motion, performance); w3.org/WAI/WCAG22/quickref/. Links fornecidos como leitura, sem auditoria online nesta versão.