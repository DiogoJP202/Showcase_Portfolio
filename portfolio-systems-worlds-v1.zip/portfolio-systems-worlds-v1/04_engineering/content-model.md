# Modelo de conteúdo e contratos

## Entidades
**SoftwareProject:** id, slug, locale, title, summary, problem, role, team, timeframe, stack, constraints, decisions[], architectureMedia[], outcomes[], learnings[], media[], links[], featured, publishStatus, updatedAt.  
**GameProject:** id, slug, locale, title, summary, genre, platform[], engine, role, status, gameplayLoop, mechanics[], iterations[], media[], playableUrl?, repoUrl?, learnings[].  
**Note:** id, slug, locale, title, excerpt, date, updatedAt, tags[], maturity?, content.  
**Reference:** url, author, region, accessedAt, observations[], hypotheses[], transferablePatterns[], rightsNotes, scores.  
**Asset:** path, alt, caption?, credit?, license?, focalPoint?, dimensions.

## Exemplo de esquema Zod (ilustrativo)
```ts
import { z } from "zod";

const Asset = z.object({
  src: z.string().min(1),
  alt: z.string(),
  caption: z.string().optional(),
  credit: z.string().optional(),
  license: z.string().optional(),
});

const Outcome = z.object({
  claim: z.string(),
  evidence: z.string().optional(),
  verified: z.boolean().default(false),
});

export const SoftwareProject = z.object({
  id: z.string(),
  slug: z.string().regex(/^[a-z0-9-]+$/),
  locale: z.enum(["pt-BR", "en-US"]),
  title: z.string().min(3),
  summary: z.string().min(20),
  role: z.string().min(2),
  problem: z.string().min(20),
  stack: z.array(z.string()),
  decisions: z.array(z.object({
    context: z.string(),
    choice: z.string(),
    alternatives: z.array(z.string()).default([]),
    tradeoff: z.string(),
  })),
  outcomes: z.array(Outcome),
  media: z.array(Asset),
  featured: z.boolean().default(false),
  publishStatus: z.enum(["draft", "review", "published"]),
});
```

## Regras de publicação
- Projeto sem papel claro não é publicado.
- Resultado quantitativo sem fonte/evidência permanece como nota interna ou é removido.
- Mídia sem direitos claros não é publicada.
- Case publicado tem summary, role, problem, ao menos uma decisão e um elemento de prova.
- Links externos são verificados em CI ou revisão periódica.
- Rascunhos não entram no sitemap.

## Internacionalização
ID canônico independe do idioma. Traduções podem ter status draft/published individual; hreflang só aponta para versões existentes. Fallback de conteúdo deve ser explícito e não misturar idiomas sem aviso.

## Modelagem de motion
Não colocar timelines no conteúdo editorial. Motion pertence a componentes e configurações de tema; conteúdo pode indicar `heroVariant` e `mediaType` sob enum validado.

## Estrutura de assets
`public/media/<project-id>/<asset-name>.<ext>`; poster de vídeo separado; legenda e crédito próximos do arquivo de conteúdo. Vídeos longos hospedados em serviço apropriado se necessário, com consentimento e fallback.