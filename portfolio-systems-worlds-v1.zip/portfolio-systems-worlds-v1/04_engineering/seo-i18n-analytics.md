# SEO, i18n, descoberta e analytics

## SEO por mundo
Home: identidade e posicionamento claros.  
Software: palavras-chave naturais sobre competências e projetos reais.  
Games: nomes dos jogos, engine, plataformas e estado.  
Pessoal: títulos editoriais descritivos, datas, tags e autoria.

## Metadados
Cada página: title único, meta description útil, canonical, Open Graph/Twitter card, idioma, imagem social, dados estruturados quando aplicáveis. Sitemap só com conteúdo publicado; robots e noindex para previews/rascunhos.

## Conteúdo rastreável
Projetos em HTML sem depender de canvas; links com href real; headings semânticos; transcrições de vídeo; legendas; imagens com alt; página de case acessível por URL direta.

## Internacionalização
Proposta: pt-BR e en-US com rotas por locale **após** validar objetivo. Alternativas: prefixo /pt e /en; ou inglês como default com /pt. Não decidir sem público principal. Slugs estáveis; traduções revisadas; hreflang bidirecional somente em pares existentes.

## Analytics com parcimônia
Eventos: `project_open`, `demo_click`, `repo_click`, `contact_click`, `world_switch`, `atlas_mode_select`. Campos mínimos: world, project_id, locale, device_category (agregado). Não enviar nomes, e-mails ou conteúdo de formulário como propriedades.

## Métricas úteis
- Abertura de cases a partir da home.
- Conversão para contato (não confundir com resultado de contratação).
- Uso de catálogo vs. atlas.
- Cliques em build/demo e repositório.
- Core Web Vitals por rota.

## Consentimento e privacidade
Escolher ferramenta conforme legislação e necessidade. Se cookies não essenciais forem usados, revisar requisitos de consentimento. Oferecer política clara e retenção limitada. Não adicionar trackers só porque são fáceis.

## Social preview
Criar três famílias de OG images, coerentes com os mundos, com fallback de título e marca. Evitar imagens sem permissão.

## Search console
Configurar propriedade de domínio após publicação, enviar sitemap, monitorar indexação, canonical e links quebrados.