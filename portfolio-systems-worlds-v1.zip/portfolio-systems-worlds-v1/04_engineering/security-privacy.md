# Segurança, privacidade, direitos e manutenção

## Modelo de ameaça simples
Superfície pequena: site público, assets, links externos e eventual formulário. Principais riscos: dependências vulneráveis, XSS em MDX, spam em formulário, vazamento de segredos, uso de assets sem licença e exposição indevida de dados pessoais.

## Medidas
- Dependências atualizadas e lockfile versionado.
- Conteúdo MDX confiável e validado; evitar HTML arbitrário de terceiros.
- Headers de segurança e CSP compatível com scripts/assets necessários.
- Segredos somente em variáveis de ambiente do servidor.
- Formulário com validação server-side, rate limiting e anti-spam quando existir.
- Links externos seguros; não inserir HTML de embeds desconhecidos sem revisão.
- Assets otimizados e varredura de metadados sensíveis de fotos.
- Backups do conteúdo e revisão de acesso ao repositório.
- Licenças de fontes, imagens, texturas, áudio, modelos 3D e ícones documentadas.

## Conteúdo profissional
Obter autorização antes de publicar telas internas, métricas, arquitetura sensível, nomes de clientes e dados de usuários. Diagramas podem ser abstratos sem revelar detalhes confidenciais. Resultados devem ser verificáveis.

## GameDev
Verificar direitos de sprites, trilhas, modelos, marcas e screenshots. Não incorporar ROMs, builds ou assets de terceiros sem licença. Demos externas devem ter aviso de compatibilidade.

## Pessoal
Escolher deliberadamente o que publicar: fotos, localização, cronologia e contatos. Não expor dados pessoais de terceiros.

## Operação
Revisão trimestral de dependências, links, cases e política de privacidade. Monitorar erros de produção. Definir responsável por renovação de domínio e hospedagem.

## Política de atribuição
Manter `CREDITS.md` com autores, links, licenças e modificações de assets externos. O showcase do pacote usa composições SVG/CSS originais e fontes de sistema.